from ._types import CalendarID

ids: list[CalendarID] = [
    {"name": "Family", "id": "family05996856561709498501@group.calendar.google.com"},
    {
        "name": "Jewell and Kat Events",
        "id": "ff908c093e0502f9352e4a368a79f77adbc45fd636efe242a37b4fb48ab290fa@group.calendar.google.com",
    },
    {"name": "Personal", "id": "cadwalladerkatelynn@gmail.com"},
    {
        "name": "Dweeb Family",
        "id": "8d0382910b83b346b08292060faf48d67c45a286a97f69e5b16469a8e88b27c4@group.calendar.google.com",
    },
    {"name": "Work", "id": "katelynn.cadwallader@botrista.com"},
]
